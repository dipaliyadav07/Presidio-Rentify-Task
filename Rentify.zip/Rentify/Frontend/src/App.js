import React, { useContext } from 'react';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import Register from './components/Register';
import Login from './components/Login';
import PropertyList from './components/PropertyList';
import PropertyManagement from './components/PropertyManagement';
import AddEditProperty from './components/AddEditProperty';
import { AuthContext } from './contexts/AuthContext';
import PrivateRoute from './PrivateRoute';

const App = () => {
    const { isAuthenticated } = useContext(AuthContext);

    return (
        <Router>
            <div className="App">
                <Switch>
                    <Route exact path="/" component={PropertyList} />
                    <Route exact path="/register" component={Register} />
                    <Route exact path="/login" component={Login} />
                    <PrivateRoute
                        exact
                        path="/manage-properties"
                        component={PropertyManagement}
                        isAuthenticated={isAuthenticated}
                    />
                    <PrivateRoute
                        exact
                        path="/add-property"
                        component={AddEditProperty}
                        isAuthenticated={isAuthenticated}
                    />
                    <PrivateRoute
                        exact
                        path="/edit-property/:id"
                        component={AddEditProperty}
                        isAuthenticated={isAuthenticated}
                    />
                    <Redirect to="/" />
                </Switch>
            </div>
        </Router>
    );
};

export default App;
