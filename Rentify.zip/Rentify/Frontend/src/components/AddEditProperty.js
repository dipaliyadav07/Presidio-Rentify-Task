import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useHistory, useParams } from 'react-router-dom';

const AddEditProperty = () => {
    const [formData, setFormData] = useState({
        place: '',
        area: '',
        bedrooms: '',
        bathrooms: '',
        hospitalsNearby: '',
        collegesNearby: '',
    });

    const history = useHistory();
    const { id } = useParams();

    useEffect(() => {
        if (id) {
            const fetchProperty = async () => {
                const res = await axios.get(`/api/properties/${id}`);
                setFormData(res.data);
            };
            fetchProperty();
        }
    }, [id]);

    const { place, area, bedrooms, bathrooms, hospitalsNearby, collegesNearby } = formData;

    const onChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

    const onSubmit = async (e) => {
        e.preventDefault();
        try {
            if (id) {
                await axios.put(`/api/properties/${id}`, formData);
            } else {
                await axios.post('/api/properties', formData);
            }
            history.push('/manage-properties');
        } catch (err) {
            console.error(err.response.data);
        }
    };

    return (
        <form onSubmit={onSubmit}>
            <div>
                <label>Place</label>
                <input type="text" name="place" value={place} onChange={onChange} required />
            </div>
            <div>
                <label>Area</label>
                <input type="number" name="area" value={area} onChange={onChange} required />
            </div>
            <div>
                <label>Bedrooms</label>
                <input type="number" name="bedrooms" value={bedrooms} onChange={onChange} required />
            </div>
            <div>
                <label>Bathrooms</label>
                <input type="number" name="bathrooms" value={bathrooms} onChange={onChange} required />
            </div>
            <div>
                <label>Nearby Hospitals</label>
                <input type="text" name="hospitalsNearby" value={hospitalsNearby} onChange={onChange} required />
            </div>
            <div>
                <label>Nearby Colleges</label>
                <input type="text" name="collegesNearby" value={collegesNearby} onChange={onChange} required />
            </div>
            <button type="submit">Submit</button>
        </form>
    );
};

export default AddEditProperty;
