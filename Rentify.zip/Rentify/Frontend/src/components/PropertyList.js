import React, { useState, useEffect } from 'react';
import axios from 'axios';

const PropertyList = () => {
    const [properties, setProperties] = useState([]);

    useEffect(() => {
        const fetchProperties = async () => {
            const res = await axios.get('/api/properties');
            setProperties(res.data);
        };

        fetchProperties();
    }, []);

    const onInterestedClick = (propertyId) => {
        // Handle the "I'm Interested" click logic here
    };

    return (
        <div>
            <h1>Properties</h1>
            {properties.map((property) => (
                <div key={property._id}>
                    <h2>{property.place}</h2>
                    <p>Area: {property.area}</p>
                    <p>Bedrooms: {property.bedrooms}</p>
                    <p>Bathrooms: {property.bathrooms}</p>
                    <p>Hospitals Nearby: {property.hospitalsNearby}</p>
                    <p>Colleges Nearby: {property.collegesNearby}</p>
                    <button onClick={() => onInterestedClick(property._id)}>I'm Interested</button>
                </div>
            ))}
        </div>
    );
};

export default PropertyList;
