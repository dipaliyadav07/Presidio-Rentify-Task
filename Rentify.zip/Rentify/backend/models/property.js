const mongoose = require('mongoose');

const PropertySchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    },
    place: {
        type: String,
        required: true,
    },
    area: {
        type: Number,
        required: true,
    },
    bedrooms: {
        type: Number,
        required: true,
    },
    bathrooms: {
        type: Number,
        required: true,
    },
    hospitalsNearby: {
        type: String,
        required: true,
    },
    collegesNearby: {
        type: String,
        required: true,
    },
});

module.exports = mongoose.model('Property', PropertySchema);
