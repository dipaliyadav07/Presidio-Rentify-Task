const express = require('express');
const router = express.Router();
const { createProperty, getProperties, getSellerProperties, updateProperty, deleteProperty } = require('../controllers/propertyController');
const auth = require('../middleware/auth');

router.post('/', auth, createProperty);
router.get('/', getProperties);
router.get('/seller', auth, getSellerProperties);
router.put('/:id', auth, updateProperty);
router.delete('/:id', auth, deleteProperty);

module.exports = router;
