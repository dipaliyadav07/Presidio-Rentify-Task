# Rentify - Where Renting Meets Simplicity

## Project Overview
Rentify is a full-stack application aimed at simplifying the process of renting properties. Owners can list their properties for rent, and potential tenants can browse these listings and express their interest. The project includes user authentication, property management, and a responsive user interface.

## Features
- User registration and authentication
- Property listing and management by owners
- Property browsing by tenants with an "I'm Interested" feature
- Email notifications for owners and tenants
- Role-based access control for viewing owner details
- Pagination and form validation
- Deployment on cloud platforms

## Tech Stack
- **Frontend**: React.js
- **Backend**: Node.js, Express.js
- **Database**: MongoDB
- **Authentication**: JWT (JSON Web Tokens)
- **Cloud Deployment**: Heroku / AWS / Azure

## Project Structure
